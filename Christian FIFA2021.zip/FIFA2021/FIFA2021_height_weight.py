import pandas as pd

df = pd.read_csv('fifa21 raw data v2.csv', low_memory=False)

# Extract the numeric part of the 'Height' and 'Weight' columns
df['Height'] = df['Height'].str.extract(r'(\d+)', expand=False).astype(float)
df['Weight'] = df['Weight'].str.extract(r'(\d+)', expand=False).astype(float)

# Convert the 'height(cm)' and 'weight(kg)' columns to numerical form
df['Height'] = pd.to_numeric(df['Height'])
df['Weight'] = pd.to_numeric(df['Weight'])

# Print DataFrame to check data
print(df[['Name', 'Height', 'Weight']].head())
