import pandas as pd

# Read Excel file
excel_file = 'ecommerce_sales_analysis.xlsx'

# Load into DataFrame
df = pd.read_excel(excel_file)

# Print DataFrame to check data
print(df)

# Export to CSV
csv_file = 'data.csv'

# Export DataFrame to CSV
df.to_csv(csv_file, index=False)

# Print message
print(f"Data exported to {csv_file}")

# Top Selling Products
#total_sales = df[['product_id','sales_month_1','sales_month_2',...]].sum(axis=1)
#top_sales = total_sales.sort_values(ascending=False).head()

# Review Score Analysis
#df['avg_review'] = df['review_score'].mean()
#corr = df['total_sales','avg_review'].corr()

# Category Comparison
#by_category = df.groupby('category')[sales_cols].sum()
#summary = by_category.total_sales.describe()

# Seasonal Trends
##monthly_sales.plot()

# Price Sensitivity
#scatter = plt.scatter(df['price'],df['total_sales'])
#elasticity = # calculate elasticity between cols