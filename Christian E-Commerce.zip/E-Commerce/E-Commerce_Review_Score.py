import pandas as pd

# Read CSV file
df = pd.read_csv('ecommerce_sales_analysis.csv')

# Calculate average review score per product
df['avg_review'] = df['review_score'].mean()

# Get correlation between total sales and avg review
corr = df[['review_score', 'avg_review']].corr()

# Print DataFrame to check data
print(df)
print(corr)
