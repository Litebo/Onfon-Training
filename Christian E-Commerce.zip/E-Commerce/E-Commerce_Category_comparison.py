import pandas as pd
# Read CSV
df = pd.read_csv('ecommerce_sales_analysis.csv')
# Define monthly sales columns
sales_cols = ['sales_month_1', 'sales_month_12']

# Summarize monthly sales by category
sales_by_cat = df.groupby('category')[sales_cols].sum()

# Calculate total sales per category
total_sales = sales_by_cat.sum(axis=1)

# Calculate average sales per category
avg_sales = total_sales / 12

# Print summary stats for comparison
print(total_sales.describe())
print(avg_sales.describe())


