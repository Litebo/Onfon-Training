import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv('ecommerce_sales_analysis.csv')

# Calculate % change in price and sales from period to period
df['%ΔPrice'] = (df['Price'] - df['Price'].shift(1))/df['Price'].shift(1)
df['%ΔSales'] = (df['Sales'] - df['Sales'].shift(1))/df['Sales'].shift(1)

# Scatter plot % price change vs % sales change
df.plot(x='%ΔPrice', y='%ΔSales', kind='scatter')
df = pd.read_csv('data.csv', usecols=['Price', 'Sales'])
df.rename(columns={'Old Price': 'Price'}, inplace=True)

# Calculate linear regression
from sklearn.linear_model import LinearRegression
lr = LinearRegression().fit(df[['%ΔPrice']], df['%ΔSales'])

# Print elasticity (slope of regression line)
print(lr.coef_)
print(df.columns)