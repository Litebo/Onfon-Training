import pandas as pd

# Load the CSV file
df = pd.read_csv('fifa21 raw data v2.csv')

# Convert 'Value' column to numerical values
df['Value'] = pd.to_numeric(df['Value'].str.replace('€', '').str.replace('M', '000000').str.replace('K', '000'), errors='coerce')

# Convert 'Wage' column to numerical values
df['Wage'] = pd.to_numeric(df['Wage'].str.replace('K', '000'), errors='coerce')  

# Convert 'Release Clause' column to numerical values
df['Release Clause'] = pd.to_numeric(df['Release Clause'].str.replace('€', '').str.replace('M', '000000').str.replace('K', '000'), errors='coerce')

# Print the first few rows of the updated DataFrame
print(df[['Value', 'Wage', 'Release Clause']].head())