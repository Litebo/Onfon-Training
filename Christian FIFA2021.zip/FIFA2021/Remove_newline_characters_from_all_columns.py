import pandas as pd

# Load the CSV file
df = pd.read_csv('fifa21 raw data v2.csv')

# Remove newline characters from all columns
df = df.apply(lambda x: x.str.replace('\n', ' ') if x.dtype == "object" else x)

# Print the modified DataFrame
print(df.head())