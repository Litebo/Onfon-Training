import pandas as pd
# Load the CSV file
df = pd.read_csv('fifa21 raw data v2.csv')

# Convert the 'Joined' column to datetime format
df['Joined'] = pd.to_datetime(df['Joined'])

# Calculate the number of years each player has been at their club
today = pd.Timestamp.now()
df['Contract'] = (today - df['Joined']).dt.days // 365

# Filter the DataFrame to get players who have been at their club for more than 10 years
long_term_players = df[df['Contract'] > 10]

# Display the filtered DataFrame with the relevant columns
print(long_term_players[['Name', 'Height', 'Weight', 'Contract']].head())